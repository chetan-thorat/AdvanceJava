package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static Connection conn;
	public static Connection getMyconnection() {
		if(conn==null) {
			try {
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				String url="jdbc:mysql://192.168.10.151:3306/dac20?useSSL=false";
				conn=DriverManager.getConnection(url,"dac20","welcome");
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return conn;
	}
	public static void closeMyConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	

}
